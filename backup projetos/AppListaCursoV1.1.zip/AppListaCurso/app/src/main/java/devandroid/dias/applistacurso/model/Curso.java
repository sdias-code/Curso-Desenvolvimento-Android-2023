package devandroid.dias.applistacurso.model;

public class Curso {
}
