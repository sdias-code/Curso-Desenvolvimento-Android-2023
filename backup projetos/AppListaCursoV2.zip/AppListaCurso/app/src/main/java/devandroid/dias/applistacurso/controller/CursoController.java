package devandroid.dias.applistacurso.controller;

public class CursoController {
}
